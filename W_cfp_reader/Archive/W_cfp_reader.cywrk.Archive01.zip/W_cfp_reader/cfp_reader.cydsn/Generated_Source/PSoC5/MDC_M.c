/*******************************************************************************
* File Name: MDC_M.c  
* Version 2.5
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "MDC_M.h"

/* APIs are not generated for P15[7:6] on PSoC 5 */
#if !(CY_PSOC5A &&\
	 MDC_M__PORT == 15 && ((MDC_M__MASK & 0xC0) != 0))


/*******************************************************************************
* Function Name: MDC_M_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None
*  
*******************************************************************************/
void MDC_M_Write(uint8 value) 
{
    uint8 staticBits = (MDC_M_DR & (uint8)(~MDC_M_MASK));
    MDC_M_DR = staticBits | ((uint8)(value << MDC_M_SHIFT) & MDC_M_MASK);
}


/*******************************************************************************
* Function Name: MDC_M_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  MDC_M_DM_STRONG     Strong Drive 
*  MDC_M_DM_OD_HI      Open Drain, Drives High 
*  MDC_M_DM_OD_LO      Open Drain, Drives Low 
*  MDC_M_DM_RES_UP     Resistive Pull Up 
*  MDC_M_DM_RES_DWN    Resistive Pull Down 
*  MDC_M_DM_RES_UPDWN  Resistive Pull Up/Down 
*  MDC_M_DM_DIG_HIZ    High Impedance Digital 
*  MDC_M_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void MDC_M_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(MDC_M_0, mode);
}


/*******************************************************************************
* Function Name: MDC_M_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro MDC_M_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 MDC_M_Read(void) 
{
    return (MDC_M_PS & MDC_M_MASK) >> MDC_M_SHIFT;
}


/*******************************************************************************
* Function Name: MDC_M_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 MDC_M_ReadDataReg(void) 
{
    return (MDC_M_DR & MDC_M_MASK) >> MDC_M_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(MDC_M_INTSTAT) 

    /*******************************************************************************
    * Function Name: MDC_M_ClearInterrupt
    ********************************************************************************
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 MDC_M_ClearInterrupt(void) 
    {
        return (MDC_M_INTSTAT & MDC_M_MASK) >> MDC_M_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 

#endif /* CY_PSOC5A... */

    
/* [] END OF FILE */
