/* ========================================
 *
 * Copyright FiberTreid, 2017
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "`$INSTANCE_NAME`.h"
//#include <device.h>
#include <project.h>

/* Data received MDIO Host */
volatile uint16 `$INSTANCE_NAME`_data_bits;

/* Internal Status Register */
volatile uint8  `$INSTANCE_NAME`_StatusRegister;

CY_ISR(`$INSTANCE_NAME`_ISR_InterruptHandler)
{
	/* Get Data from FIFO f1 */
	`$INSTANCE_NAME`_data_bits = CY_GET_REG16(`$INSTANCE_NAME`_FIFO_F1_PTR);
	
	/* Clear control register */
	`$INSTANCE_NAME`_CONTROL_REG &= `$INSTANCE_NAME`_ENABLE;
	
	/* Set complete status bit */
	`$INSTANCE_NAME`_StatusRegister = `$INSTANCE_NAME`_MDIO_STS_CMPLT;
	
    /*  Place your Interrupt code here. */
    /* `#START CounterISR_Interrupt` */

    /* `#END` */
}




/* [] END OF FILE */
